<template>
    <div>Register Component</div>
</template>
<script>
export default {

}
</script>
