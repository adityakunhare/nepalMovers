<script src="{{asset('admin/js/vendor/jquery-2.2.4.min.js')}}"></script>
<script src="{{asset('admin/js/popper.min.js')}}"></script>
<script src="{{asset('admin/js/bootstrap.min.js')}}"></script>
<script src="{{asset('admin/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('admin/js/metisMenu.min.js')}}"></script>
<script src="{{asset('admin/js/jquery.slimscroll.min.js')}}"></script>
<script src="{{asset('admin/js/jquery.slicknav.min.js')}}"></script>
 <!-- others plugins -->
<script src="{{asset('admin/js/plugins.js')}}"></script>
<script src="{{asset('admin/js/scripts.js')}}"></script>
@stack('script')
