<script src="{{ asset('front/js/jquery.min.js') }}"></script>
<script src="{{ asset('front/js/script.js')}}"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<!-- Scripts -->
@stack('script')
